#pragma once
using namespace std;
#include<string>
class Reanimation
{
	public:
	int rday, pday, gday, rprice, pprice;
	string name, lastname, diagnose;
	void printperson();
	int totalprice();
};

